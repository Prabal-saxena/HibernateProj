package Service;

import Entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository stdRepo;
    // Create Student data

    public Student addStudent(Student std){
        return stdRepo.save(std);
    }

    // Update Student data

    public String updateStudentById(Student std) {
        Student original = stdRepo.findById(std.getId()).orElse(std);
        original.setEmail(std.getEmail());
        original.setFirstName(std.getFirstName());
        original.setLastName(std.getLastName());
        stdRepo.save(original);
        return "Student Data Updated!!";
    }

    // Delete Student data

    public String deleteStudentByID(int id){
        stdRepo.deleteById(id);
        return "Student ID = "+id+" deleted!!" ;
    }

    // Get Student data

    public Student getStudentByName(String name){
        return stdRepo.findByName(name);
    }

}
