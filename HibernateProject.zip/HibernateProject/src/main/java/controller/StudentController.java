package controller;

import Service.StudentService;
import Entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class StudentController {

    @Autowired
    StudentService stdDao;
    // Get Student Data
    //@RequestMapping("/getStudent/{name}")
    //public Student getStudent(@PathVariable String name){
    //    return stdDao.getStudentByName(name);
    //}

    // Add Student
    @PostMapping("/addStudent")
    public Student addStudent(@RequestBody Student std){
        return stdDao.addStudent(std);
    }

    // Update Student
    @PutMapping("/updateStudent")
    public String updateStudent(@RequestBody Student std){
        return stdDao.updateStudentById(std);
    }

    // Delete Student Data
    @DeleteMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable int id){
        return stdDao.deleteStudentByID(id);
    }
}
